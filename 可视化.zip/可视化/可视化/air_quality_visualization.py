#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import dash
from dash import dcc, html, callback
from dash.dependencies import Input, Output
import warnings

warnings.filterwarnings('ignore')

# 定义数据路径
DATA_DIR = r'D:\desk\可视化\可视化\需要可视化的数据'
SPECIFIED_SITES_DIR = os.path.join(DATA_DIR, '指定的三个地点')
OTHER_SITES_DIR = os.path.join(DATA_DIR, '其他参考数据')

# ====================
# 数据加载和预处理部分
# ====================
def load_data():
    """加载所有站点的数据并进行预处理"""
    
    # 收集所有数据文件路径
    all_files = []
    for root, _, files in os.walk(DATA_DIR):
        for file in files:
            if file.endswith('.csv'):
                all_files.append(os.path.join(root, file))
    
    # 加载所有数据
    print("正在加载数据...")
    data_frames = []
    station_names = []
    
    for file_path in all_files:
        file_name = os.path.basename(file_path)
        station_name = file_name.replace('清洗-', '').replace('.csv', '')
        print(f"加载站点：{station_name}")
        
        # 读取CSV数据
        df = pd.read_csv(file_path)
        df['station'] = station_name  # 添加站点名列
        data_frames.append(df)
        station_names.append(station_name)
    
    # 合并所有数据框
    print("合并数据...")
    all_data = pd.concat(data_frames, ignore_index=True)
    
    # 数据预处理
    print("数据预处理...")
    all_data = preprocess_data(all_data)
    
    return all_data, station_names

def preprocess_data(df):
    """对数据进行预处理"""
    
    # 转换时间列为datetime类型，使用更灵活的方式处理不同格式
    try:
        # 首先尝试自动解析
        df['timepoint'] = pd.to_datetime(df['timepoint'], errors='coerce')
        
        # 检查是否有无法解析的时间，如果有尝试特定格式
        if df['timepoint'].isna().any():
            # 找出未成功解析的时间字符串
            mask = df['timepoint'].isna()
            problematic_times = df.loc[mask, 'timepoint_original'] if 'timepoint_original' in df.columns else df.loc[mask, 'timepoint']
            
            print(f"发现{len(problematic_times)}个无法自动解析的时间格式，尝试特定格式解析...")
            for idx, time_str in problematic_times.items():
                if isinstance(time_str, str):
                    if 'T' in time_str:
                        parts = time_str.split('T')
                        if len(parts) == 2:
                            date_part = parts[0]
                            time_part = parts[1]
                            
                            # 处理不带冒号的时间部分，如 '2200'
                            if ':' not in time_part and len(time_part) == 4:
                                time_part = time_part[:2] + ':' + time_part[2:] + ':00'
                            elif ':' not in time_part and len(time_part) == 2:
                                time_part = time_part + ':00:00'
                            
                            # 重新组合时间字符串
                            fixed_time_str = f"{date_part}T{time_part}"
                            try:
                                df.loc[idx, 'timepoint'] = pd.to_datetime(fixed_time_str)
                            except:
                                # 如果仍然失败，保留为NaT
                                pass
    except Exception as e:
        print(f"时间解析过程中出现错误: {e}")
        # 备份原始时间列以供分析
        if 'timepoint_original' not in df.columns:
            df['timepoint_original'] = df['timepoint']
        # 使用更宽松的解析
        df['timepoint'] = pd.to_datetime(df['timepoint'], format='mixed', errors='coerce')
    
    # 移除仍然无法解析的行
    invalid_times = df['timepoint'].isna().sum()
    if invalid_times > 0:
        print(f"警告: 有{invalid_times}行的时间无法解析，这些行将被删除")
        df = df.dropna(subset=['timepoint'])
    
    # 提取日期的各个组成部分，便于后续分析
    df['year'] = df['timepoint'].dt.year
    df['month'] = df['timepoint'].dt.month
    df['day'] = df['timepoint'].dt.day
    df['hour'] = df['timepoint'].dt.hour
    df['dayofweek'] = df['timepoint'].dt.dayofweek  # 0=星期一, 6=星期日
    
    # 创建季节列
    season_map = {1: '冬季', 2: '冬季', 3: '春季', 4: '春季', 5: '春季', 
                  6: '夏季', 7: '夏季', 8: '夏季', 9: '秋季', 10: '秋季', 
                  11: '秋季', 12: '冬季'}
    df['season'] = df['month'].map(season_map)
    
    # 处理缺失值 (对于数值列，用各站点同一指标的均值填充)
    numeric_cols = ['aqi', 'pm10', 'pm10_24h', 'pm2_5', 'pm2_5_24h', 
                   'o3', 'o3_24h', 'o3_8h', 'o3_8h_24h', 
                   'no2', 'no2_24h', 'so2', 'so2_24h', 
                   'co', 'co_24h']
    
    for col in numeric_cols:
        # 确保数值列都是float类型
        df[col] = pd.to_numeric(df[col], errors='coerce')
    
    # 按站点填充缺失值
    for station in df['station'].unique():
        for col in numeric_cols:
            mask = (df['station'] == station) & df[col].isna()
            df.loc[mask, col] = df[df['station'] == station][col].mean()
    
    # 对任何剩余的缺失值，用全局均值填充
    for col in numeric_cols:
        df[col].fillna(df[col].mean(), inplace=True)
    
    return df

# ====================
# 可视化函数部分
# ====================

def create_time_series(df, station, pollutant, time_scale, smoothing=False):
    """
    创建时间序列图
    
    参数:
    df: 数据框
    station: 站点名称、列表或'all'表示所有站点
    pollutant: 污染物指标
    time_scale: 时间尺度 ('hour', 'day', 'month', 'year')
    smoothing: 是否应用平滑处理
    """
    
    # 过滤站点
    if station == 'all':
        # 使用所有站点
        filtered_df = df
        station_title = '所有站点'
    elif isinstance(station, list):
        filtered_df = df[df['station'].isin(station)]
        station_title = ', '.join(station)
    else:
        filtered_df = df[df['station'] == station]
        station_title = station
    
    # 根据时间尺度进行聚合
    if time_scale == 'hour':
        # 小时数据不需要聚合
        agg_df = filtered_df
        date_col = 'timepoint'
    elif time_scale == 'day':
        agg_df = filtered_df.groupby(['station', 'year', 'month', 'day'])[pollutant].mean().reset_index()
        agg_df['date'] = pd.to_datetime(agg_df[['year', 'month', 'day']])
        date_col = 'date'
    elif time_scale == 'month':
        agg_df = filtered_df.groupby(['station', 'year', 'month'])[pollutant].mean().reset_index()
        agg_df['date'] = pd.to_datetime(agg_df[['year', 'month']].assign(day=1))
        date_col = 'date'
    elif time_scale == 'year':
        agg_df = filtered_df.groupby(['station', 'year'])[pollutant].mean().reset_index()
        agg_df['date'] = pd.to_datetime(agg_df['year'].astype(str))
        date_col = 'date'
    
    # 创建时间序列图
    fig = px.line(
        agg_df, 
        x=date_col, 
        y=pollutant,
        color='station',
        title=f"{station_title} - {pollutant} 时间序列 ({time_scale})",
        labels={pollutant: f"{pollutant} 浓度", date_col: "时间"},
        template='plotly_white'
    )
    
    # 应用移动平均平滑处理
    if smoothing and len(agg_df) > 5:
        for station_name in agg_df['station'].unique():
            station_df = agg_df[agg_df['station'] == station_name].sort_values(by=date_col)
            
            # 计算移动平均
            window_size = 24 if time_scale == 'hour' else 7 if time_scale == 'day' else 3
            station_df['smoothed'] = station_df[pollutant].rolling(window=window_size, center=True).mean()
            
            # 添加平滑曲线
            fig.add_trace(
                go.Scatter(
                    x=station_df[date_col],
                    y=station_df['smoothed'],
                    mode='lines',
                    line=dict(width=3, dash='dot'),
                    name=f"{station_name} (平滑)",
                    hoverinfo='none'
                )
            )
    
    # 增强交互性
    fig.update_layout(
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        xaxis=dict(rangeslider=dict(visible=True)),
        height=600
    )
    
    return fig

def create_heatmap(df, station, pollutant, heatmap_type):
    """
    创建热图
    
    参数:
    df: 数据框
    station: 站点名称
    pollutant: 污染物指标
    heatmap_type: 热图类型 ('hour_day', 'month_year')
    """
    
    # 过滤站点数据
    if station != 'all':
        filtered_df = df[df['station'] == station]
    else:
        filtered_df = df
    
    if heatmap_type == 'hour_day':
        # 按小时和日期聚合
        pivot_df = filtered_df.groupby(['hour', 'day'])[pollutant].mean().reset_index()
        pivot_table = pivot_df.pivot(index='day', columns='hour', values=pollutant)
        
        title = f"{station} - {pollutant} 小时-日热图"
        x_title = "小时"
        y_title = "日期"
    
    elif heatmap_type == 'month_year':
        # 按月份和年份聚合
        pivot_df = filtered_df.groupby(['year', 'month'])[pollutant].mean().reset_index()
        pivot_table = pivot_df.pivot(index='year', columns='month', values=pollutant)
        
        title = f"{station} - {pollutant} 月-年热图"
        x_title = "月份"
        y_title = "年份"
    
    elif heatmap_type == 'hour_weekday':
        # 按小时和星期几聚合
        weekday_names = {0: '周一', 1: '周二', 2: '周三', 3: '周四', 4: '周五', 5: '周六', 6: '周日'}
        filtered_df['weekday_name'] = filtered_df['dayofweek'].map(weekday_names)
        
        pivot_df = filtered_df.groupby(['hour', 'dayofweek', 'weekday_name'])[pollutant].mean().reset_index()
        pivot_table = pivot_df.pivot(index='weekday_name', columns='hour', values=pollutant)
        
        # 确保星期几的顺序正确
        pivot_table = pivot_table.reindex(['周一', '周二', '周三', '周四', '周五', '周六', '周日'])
        
        title = f"{station} - {pollutant} 小时-星期热图"
        x_title = "小时"
        y_title = "星期"
    
    # 创建热图
    fig = px.imshow(
        pivot_table,
        labels=dict(x=x_title, y=y_title, color=f"{pollutant} 浓度"),
        title=title,
        color_continuous_scale="Viridis",
        template='plotly_white'
    )
    
    # 增强交互性
    fig.update_layout(
        height=600,
        coloraxis_colorbar=dict(title=f"{pollutant} 浓度")
    )
    
    return fig

def create_boxplot(df, pollutant, group_by):
    """
    创建箱线图
    
    参数:
    df: 数据框
    pollutant: 污染物指标
    group_by: 分组依据 ('station', 'month', 'season')
    """
    
    if group_by == 'station':
        # 按站点分组
        fig = px.box(
            df, 
            x='station', 
            y=pollutant,
            title=f"各站点 {pollutant} 分布箱线图",
            labels={'station': '站点', pollutant: f"{pollutant} 浓度"},
            template='plotly_white'
        )
    
    elif group_by == 'month':
        # 按月份分组，添加颜色区分站点
        fig = px.box(
            df,
            x='month',
            y=pollutant,
            color='station',
            title=f"各站点按月份分组的 {pollutant} 箱线图",
            labels={'month': '月份', pollutant: f"{pollutant} 浓度", 'station': '站点'},
            template='plotly_white'
        )
        # 月份标签
        month_names = {1: '一月', 2: '二月', 3: '三月', 4: '四月', 5: '五月', 6: '六月',
                      7: '七月', 8: '八月', 9: '九月', 10: '十月', 11: '十一月', 12: '十二月'}
        fig.update_xaxes(tickvals=list(month_names.keys()), ticktext=list(month_names.values()))
    
    elif group_by == 'season':
        # 按季节分组
        fig = px.box(
            df,
            x='season',
            y=pollutant,
            color='station',
            title=f"各站点按季节分组的 {pollutant} 箱线图",
            labels={'season': '季节', pollutant: f"{pollutant} 浓度", 'station': '站点'},
            template='plotly_white',
            category_orders={"season": ["春季", "夏季", "秋季", "冬季"]}
        )
    
    # 增强交互性
    fig.update_layout(
        height=600,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )
    
    return fig

def create_correlation_heatmap(df, station, time_filter):
    """
    创建相关性热图
    
    参数:
    df: 数据框
    station: 站点名称
    time_filter: 时间过滤条件 ('all', '2022', '2023', ...)
    """
    
    # 过滤站点数据
    if station != 'all':
        filtered_df = df[df['station'] == station]
    else:
        filtered_df = df
    
    # 应用时间过滤
    if time_filter != 'all':
        filtered_df = filtered_df[filtered_df['year'] == int(time_filter)]
    
    # 污染物指标列表
    pollutants = ['aqi', 'pm10', 'pm2_5', 'o3', 'o3_8h', 'no2', 'so2', 'co']
    
    # 计算相关系数矩阵
    corr_matrix = filtered_df[pollutants].corr()
    
    # 创建热图
    fig = px.imshow(
        corr_matrix,
        labels=dict(x="污染物", y="污染物", color="相关系数"),
        x=pollutants,
        y=pollutants,
        color_continuous_scale="RdBu_r",
        title=f"{station} - 污染物相关性热图 ({time_filter})",
        template='plotly_white',
        text_auto=True
    )
    
    # 增强交互性
    fig.update_layout(
        height=700,
        width=700
    )
    
    return fig

# ====================
# Dash应用部分
# ====================

def create_app(df, stations):
    """创建Dash Web应用"""
    
    app = dash.Dash(__name__, title="空气质量数据可视化平台")
    
    # 污染物列表
    pollutants = ['aqi', 'pm10', 'pm2_5', 'o3', 'o3_8h', 'no2', 'so2', 'co']
    
    # 定义年份选项
    years = sorted(df['year'].unique())
    
    # 布局
    app.layout = html.Div([
        html.H1("空气质量数据可视化平台", style={'textAlign': 'center', 'marginBottom': 30}),
        
        dcc.Tabs([
            # 第一个选项卡：时间序列图
            dcc.Tab(label="时间序列图", children=[
                html.Div([
                    html.Div([
                        html.Label("选择站点:"),
                        dcc.Dropdown(
                            id='time-series-station',
                            options=[{'label': s, 'value': s} for s in stations] + [{'label': '所有站点', 'value': 'all'}],
                            value=stations[0],
                            clearable=False
                        ),
                        
                        html.Label("选择污染物:"),
                        dcc.Dropdown(
                            id='time-series-pollutant',
                            options=[{'label': p, 'value': p} for p in pollutants],
                            value='pm2_5',
                            clearable=False
                        ),
                        
                        html.Label("时间尺度:"),
                        dcc.RadioItems(
                            id='time-series-scale',
                            options=[
                                {'label': '小时', 'value': 'hour'},
                                {'label': '日', 'value': 'day'},
                                {'label': '月', 'value': 'month'},
                                {'label': '年', 'value': 'year'}
                            ],
                            value='day',
                            labelStyle={'display': 'inline-block', 'margin-right': '10px'}
                        ),
                        
                        html.Label("应用平滑处理:"),
                        dcc.RadioItems(
                            id='time-series-smoothing',
                            options=[
                                {'label': '是', 'value': 'True'},
                                {'label': '否', 'value': 'False'}
                            ],
                            value='True',
                            labelStyle={'display': 'inline-block', 'margin-right': '10px'}
                        ),
                    ], style={'width': '30%', 'display': 'inline-block', 'vertical-align': 'top', 'padding': '20px'}),
                    
                    html.Div([
                        dcc.Graph(id='time-series-graph')
                    ], style={'width': '70%', 'display': 'inline-block', 'padding': '20px'})
                ])
            ]),
            
            # 第二个选项卡：热图
            dcc.Tab(label="热图", children=[
                html.Div([
                    html.Div([
                        html.Label("选择站点:"),
                        dcc.Dropdown(
                            id='heatmap-station',
                            options=[{'label': s, 'value': s} for s in stations] + [{'label': '所有站点', 'value': 'all'}],
                            value=stations[0],
                            clearable=False
                        ),
                        
                        html.Label("选择污染物:"),
                        dcc.Dropdown(
                            id='heatmap-pollutant',
                            options=[{'label': p, 'value': p} for p in pollutants],
                            value='pm2_5',
                            clearable=False
                        ),
                        
                        html.Label("热图类型:"),
                        dcc.RadioItems(
                            id='heatmap-type',
                            options=[
                                {'label': '小时-日热图', 'value': 'hour_day'},
                                {'label': '小时-星期热图', 'value': 'hour_weekday'},
                                {'label': '月-年热图', 'value': 'month_year'}
                            ],
                            value='hour_weekday',
                            labelStyle={'display': 'block'}
                        )
                    ], style={'width': '30%', 'display': 'inline-block', 'vertical-align': 'top', 'padding': '20px'}),
                    
                    html.Div([
                        dcc.Graph(id='heatmap-graph')
                    ], style={'width': '70%', 'display': 'inline-block', 'padding': '20px'})
                ])
            ]),
            
            # 第三个选项卡：箱线图
            dcc.Tab(label="箱线图", children=[
                html.Div([
                    html.Div([
                        html.Label("选择污染物:"),
                        dcc.Dropdown(
                            id='boxplot-pollutant',
                            options=[{'label': p, 'value': p} for p in pollutants],
                            value='pm2_5',
                            clearable=False
                        ),
                        
                        html.Label("分组依据:"),
                        dcc.RadioItems(
                            id='boxplot-group',
                            options=[
                                {'label': '站点', 'value': 'station'},
                                {'label': '月份', 'value': 'month'},
                                {'label': '季节', 'value': 'season'}
                            ],
                            value='station',
                            labelStyle={'display': 'block'}
                        )
                    ], style={'width': '30%', 'display': 'inline-block', 'vertical-align': 'top', 'padding': '20px'}),
                    
                    html.Div([
                        dcc.Graph(id='boxplot-graph')
                    ], style={'width': '70%', 'display': 'inline-block', 'padding': '20px'})
                ])
            ]),
            
            # 第四个选项卡：相关性热图
            dcc.Tab(label="相关性热图", children=[
                html.Div([
                    html.Div([
                        html.Label("选择站点:"),
                        dcc.Dropdown(
                            id='corr-station',
                            options=[{'label': s, 'value': s} for s in stations] + [{'label': '所有站点', 'value': 'all'}],
                            value=stations[0],
                            clearable=False
                        ),
                        
                        html.Label("时间过滤:"),
                        dcc.Dropdown(
                            id='corr-time-filter',
                            options=[{'label': '全部时间', 'value': 'all'}] + 
                                    [{'label': str(year), 'value': str(year)} for year in years],
                            value='all',
                            clearable=False
                        )
                    ], style={'width': '30%', 'display': 'inline-block', 'vertical-align': 'top', 'padding': '20px'}),
                    
                    html.Div([
                        dcc.Graph(id='correlation-graph')
                    ], style={'width': '70%', 'display': 'inline-block', 'padding': '20px'})
                ])
            ])
        ])
    ], style={'padding': '20px'})
    
    # 回调函数
    
    # 时间序列图回调
    @app.callback(
        Output('time-series-graph', 'figure'),
        [Input('time-series-station', 'value'),
         Input('time-series-pollutant', 'value'),
         Input('time-series-scale', 'value'),
         Input('time-series-smoothing', 'value')]
    )
    def update_time_series(station, pollutant, time_scale, smoothing):
        smoothing_bool = smoothing == 'True'
        # 处理站点选择
        station_selection = station
        # 添加加载提示
        print(f"生成时间序列图: 站点={station_selection}, 污染物={pollutant}, 时间尺度={time_scale}")
        return create_time_series(df, station_selection, pollutant, time_scale, smoothing_bool)
    
    # 热图回调
    @app.callback(
        Output('heatmap-graph', 'figure'),
        [Input('heatmap-station', 'value'),
         Input('heatmap-pollutant', 'value'),
         Input('heatmap-type', 'value')]
    )
    def update_heatmap(station, pollutant, heatmap_type):
        return create_heatmap(df, station, pollutant, heatmap_type)
    
    # 箱线图回调
    @app.callback(
        Output('boxplot-graph', 'figure'),
        [Input('boxplot-pollutant', 'value'),
         Input('boxplot-group', 'value')]
    )
    def update_boxplot(pollutant, group_by):
        return create_boxplot(df, pollutant, group_by)
    
    # 相关性热图回调
    @app.callback(
        Output('correlation-graph', 'figure'),
        [Input('corr-station', 'value'),
         Input('corr-time-filter', 'value')]
    )
    def update_correlation(station, time_filter):
        return create_correlation_heatmap(df, station, time_filter)
    
    return app

# ====================
# 主程序入口
# ====================

if __name__ == "__main__":
    # 加载并预处理数据
    all_data, station_names = load_data()
    
    # 创建Dash应用
    app = create_app(all_data, station_names)
    
    # 运行应用
    print("启动可视化平台...")
    app.run(debug=True, port=8050)
    
    print("应用已关闭。")
